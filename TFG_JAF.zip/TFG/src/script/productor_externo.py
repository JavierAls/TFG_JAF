#!/usr/bin/env python3

import rospy
import random
from std_msgs.msg import Int64 
from std_msgs.msg import Bool

#este nodo se encarga de producir un cubo cada vez que le llega una señal proveniente de la estación de llegada mediante el topic /produce_new_cube.
#los cubos se van a producir de manera aleatoria y van a ser rojos o azules.

def NewCube(msg):
    global produce_cube
    produce_cube=msg.data
    #print("producir cubo: ",msg.data)
    

    
if __name__ == '__main__':
    rospy.init_node('productor_externo')
    
    #publisher tipo de cubo
    pub = rospy.Publisher("/cube_type",Int64,queue_size=10)
    #subscriber para producir nuevo cubo
    sub= rospy.Subscriber("/produce_new_cube",Bool,NewCube)
    
    #Inicializamos
    msg=Int64()
    produce_cube=True
    
    #i=0
    
    while not rospy.is_shutdown():
        rospy.sleep(2)
        msg.data=random.randint(1,2)
        
        while produce_cube==False:
              rospy.sleep(1)
        #print('cubos producidos: ',i)      
        
        if msg.data==1: 
             print("Produciendo un cubo rojo")
        
        elif msg.data==2:
             print("Produciendo un cubo azul")
        
        #print(msg)     
        pub.publish(msg)
        
        while produce_cube==True:
              rospy.sleep(1)
     
        #i=i+1
           
    sub.unregister()
    pub.unregister()    
    rospy.signal_shutdown('Programa finalizado')
