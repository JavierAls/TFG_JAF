#!/usr/bin/env python3

import numpy
import rospy
from std_msgs.msg import Int64 
from std_msgs.msg import String
from std_msgs.msg import Bool


#este nodo es el encargado de:
#1. Detectar que se ha producido una pieza y qué tipo es. Se crea un vector con el tipo de pieza.
#2. Comparar los estados, posición de los AGVs para ver cual es el mejor posicionado para ir. La prioridad aumentará conforme más cerca se encuentre de la estación de llegada.
#3. Enviar el AGV seleccionado a la estación deseada para recoger la pieza. Esto se hace mandando el nombre del AGV seleccionado(\AGV_sent) y la tarea que debe hacer(\task).
    #Se quita el cubo del vector creado antes

def need_AGV(msg):
    global cube
    cube=msg.data
    #print("Nuevo cubo recibido: ",msg.data)
    
class AGV:
   def __init__(self,nombre,AGV_free,AGV_position):
        self.nombre=nombre
        self.AGV_free=AGV_free
        self.AGV_position=AGV_position    
    
def freeornot1(msg):
    global free1
    free1=msg.data
    
def freeornot2(msg):
    global free2
    free2=msg.data
    
def freeornot3(msg):
    global free3
    free3=msg.data
    
def freeornot4(msg):
    global free4
    free4=msg.data
    
    
def positionAGV1(msg):
    global position1
    position1=msg.data    
    
def positionAGV2(msg):
    global position2
    position2=msg.data 
    
def positionAGV3(msg):
    global position3
    position3=msg.data 
    
def positionAGV4(msg):
    global position4
    position4=msg.data        



if __name__=='__main__':
    rospy.init_node('manager')
    
    #subscribers
    subs_producer=rospy.Subscriber("/cube_type",Int64,need_AGV)
    subscriber_free1=rospy.Subscriber("/free_AGV1",Bool,freeornot1)
    subscriber_free2=rospy.Subscriber("/free_AGV2",Bool,freeornot2)
    subscriber_free3=rospy.Subscriber("/free_AGV3",Bool,freeornot3)
    subscriber_free4=rospy.Subscriber("/free_AGV4",Bool,freeornot4)
    subscriber_position1=rospy.Subscriber("/position_AGV1",Int64,positionAGV1)
    subscriber_position2=rospy.Subscriber("/position_AGV2",Int64,positionAGV2)
    subscriber_position3=rospy.Subscriber("/position_AGV3",Int64,positionAGV3)
    subscriber_position4=rospy.Subscriber("/position_AGV4",Int64,positionAGV4)
    
    #publishers
    pub_AGV_sent = rospy.Publisher("/AGV_sent",String,queue_size=10)
    pub_task_AGV = rospy.Publisher("/task",Int64,queue_size=10)
    
    #se crea un array para las tareas 
    tasks=[]
    #first_task=Int64()
    i=Int64()
    i=0
    #Inicializar variables globales
    cube=0
    free1=True
    free2=True
    free3=True
    free4=True
    position1=6
    position2=7
    position3=8
    position4=9
    
    
    while not rospy.is_shutdown():
       
     #Detectar que se ha producido una pieza y qué tipo es.
       AGV_seleccionado="Ninguno"
       if cube!=0:
          tasks.append(cube)
        #variable cl usada como contador para almacenar la cercanía. La ponemos de principio en 10 para saber si no hay ninguno libre(no existe la 10 estación)
          cl=Int64()
          cl=10          
          t=1
          
          #print('Seleccionando AGV')
          flota=["AGV1","AGV2","AGV3","AGV4"]
          for i in flota:  
             agv=AGV(i,globals()["free"+str(t)],globals()["position"+str(t)])
             #print(agv.AGV_free)
             #print(agv.AGV_position) 
             if agv.AGV_free == False:
                  rospy.sleep(0.001)
           
             #comprobamos si está más cerca que el anterior, para el caso de la estación 5 se prorizará los que esteń más cerca.
             elif (int(agv.AGV_position)<int(cl)) or (cl==5):
                cl=int(agv.AGV_position)
                AGV_seleccionado=agv.nombre
             t=t+1
             
          #después de compararlos, mandamos uno
          #el propio AGV comprueba si su nombre es el mismo  
          pub_AGV_sent.publish(AGV_seleccionado)           
          rospy.sleep(0.01)
          
          #se quita la tarea de la lista
          if AGV_seleccionado!="Ninguno": 
            #print('AGV seleccionado para recoger pieza: ',AGV_seleccionado)
            #el tipo de pieza que se manda se saca de la lista del primer puesto y se añade al topic task
            cube=0
            #print('Pieza mandada por el manager: ',tasks[0])
            pub_task_AGV.publish(tasks[0]) 
            tasks.clear()
            
            
               
          
     
   

     

