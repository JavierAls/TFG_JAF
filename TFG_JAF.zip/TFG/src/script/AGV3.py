#!/usr/bin/env python3

import numpy
import rospy
from std_msgs.msg import Int64 
from std_msgs.msg import String
from std_msgs.msg import Bool


#este nodo se ejecutará para controlar la ruta del AGV3. Se encargará de:
#1. Comprobar si es el AGV seleccionado para una tarea. Comparar su nombre con el nombre publicado en /AGV_sent.
#2. Si lo es, establecer su estado como ocupado(/freeAGV3) mandarlo a la estación 0 a recoger la pieza y subscribirme al topic /task para saber tipo pieza, y por tanto la ruta que deberá seguir posteriormente.
#Mientras se sigue la ruta se irá actualizando la batería y la posición. Al acabar se pondrá como libre el AGV. 
#3.Cuando la pieza sea procesada y colocada encima del AGV(/cube_ready_station(nº)), antes de mandalo a la siguiente se comprobará que no haya ningún AGV en la siguiente estación mediante el topic /AGV_in_station(nº de la siguiente)
#4. Al final, se comprobará el estado de la batería y si debe ser cargado.

def AGVsent(msg):
    global AGV_sent
    AGV_sent=msg.data
    #print("AGV_sent: ",msg.data)
    
def Piece(msg):
    global task
    task=msg.data

    
def AGVst0(msg):
    global AGV_station0
    AGV_station0=msg.data
    
    
def AGVst1(msg):
    global AGV_station1
    AGV_station1=msg.data
    
def AGVst2(msg):
    global AGV_station2
    AGV_station2=msg.data
    
def AGVst3(msg):
    global AGV_station3
    AGV_station3=msg.data
    
    
def AGVst4(msg):
    global AGV_station4
    AGV_station4=msg.data
    
def AGVst5(msg):
    global AGV_station5
    AGV_station5=msg.data
    
def AGVst8(msg):
    global AGV_station8
    AGV_station8=msg.data
    
def Cubeinst0(msg):
    global Cube_ready_st0
    Cube_ready_st0=msg.data
    
def Cubeinst1(msg):
    global Cube_ready_st1
    Cube_ready_st1=msg.data
    
def Cubeinst2(msg):
    global Cube_ready_st2
    Cube_ready_st2=msg.data
    
def Cubeinst3(msg):
    global Cube_ready_st3
    Cube_ready_st3=msg.data
    
    
def Cubeinst4(msg):
    global Cube_ready_st4
    Cube_ready_st4=msg.data
    
def Cubeinst5(msg):
    global AGV_ready_st5
    AGV_ready_st5=msg.data


if __name__=='__main__':
    rospy.init_node('AGV3')
    
    Path=String
    Battery_level=Int64
    Battery_level=100
    Position=Int64()
    #posicion inicial
    Position=8
    #Inicializamos variables globales
    AGV_station0=False
    AGV_station1=False
    AGV_station2=False
    AGV_station3=False
    AGV_station4=False
    AGV_station5=False
    AGV_station8=True
    Cube_ready_st0=False
    Cube_ready_st1=False
    Cube_ready_st2=False
    Cube_ready_st3=False
    Cube_ready_st4=False
    AGV_ready_st5=False
    
    AGV_sent="Ninguno"
    task=0
    
    #Publishers
    pub_path_AGV = rospy.Publisher("/PathAGV3",String,queue_size=10)
    pub_battery_lvl=rospy.Publisher("/battery_lvl_AGV3",Int64,queue_size=10)
    pub_free=rospy.Publisher("/free_AGV3",Bool,queue_size=1)
    pub_position=rospy.Publisher("/position_AGV3",Int64,queue_size=10)
    
    #Subscribers
    sub_AGV_sent=rospy.Subscriber("/AGV_sent",String,AGVsent)
    sub_task_AGV=rospy.Subscriber("/task",Int64,Piece)
    sub_station0free=rospy.Subscriber("/AGV_in_station0",Bool,AGVst0)
    sub_station1free=rospy.Subscriber("/AGV_in_station1",Bool,AGVst1)
    sub_station2free=rospy.Subscriber("/AGV_in_station2",Bool,AGVst2)
    sub_station3free=rospy.Subscriber("/AGV_in_station3",Bool,AGVst3)
    sub_station4free=rospy.Subscriber("/AGV_in_station4",Bool,AGVst4)
    sub_station5free=rospy.Subscriber("/AGV_in_station5",Bool,AGVst5) 
    sub_inicial=rospy.Subscriber("/AGV_in_station8",Bool,AGVst8)   
       #cubo encima del AGV
    sub_cube_ready0=rospy.Subscriber("/cube_ready_station0",Bool,Cubeinst0)
    sub_cube_ready1=rospy.Subscriber("/cube_ready_station1",Bool,Cubeinst1)
    sub_cube_ready2=rospy.Subscriber("/cube_ready_station2",Bool,Cubeinst2)
    sub_cube_ready3=rospy.Subscriber("/cube_ready_station3",Bool,Cubeinst3)
    sub_cube_ready4=rospy.Subscriber("/cube_ready_station4",Bool,Cubeinst4)
    sub_AGV_ready5=rospy.Subscriber("/AGV_ready_station5",Bool,Cubeinst5)

    
    
    while not rospy.is_shutdown():
           
       pub_position.publish(Position)
       pub_battery_lvl.publish(Battery_level)
       #print('posición AGV3: ',Position)
       #comprobamos batería
       if Battery_level<25:
          pub_free.publish(False) 
          Path="/Path5_8"
          pub_path_AGV.publish(Path) 
          print('AGV3 tiene poca batería, necesita ser cargado')
          #el tiempo de carga dura en total mientras llega y se carga 30 seg
          rospy.sleep(50)
          Battery_level=100
          pub_battery_lvl.publish(Battery_level)
          Position=8
          pub_position.publish(Position)
          print('AGV3 cargado')
          
       pub_free.publish(True)    
       rospy.sleep(1)
       
       #print('AGV registrado:',AGV_sent)
       
       if AGV_sent=="AGV3": 
          print('Comenzamos navegación AGV3')
          pub_free.publish(False)
          #inicio o despues de carga
          if Position==8:
             #mandamos el path al AGV de su posición de inicio a la estación 0
             Path="/Path8_0"
          
          #si es llamado nada más dejar la pieza en la estación 5
          else: 
             Path="/Path5_0"
           
          #esperamos que no haya ningun AGV st 0:
          
          while AGV_station0==True:
               if Position==5:
                  AGV_station0=False
                  rospy.sleep(2.5)
               else:
                  rospy.sleep(0.001)
                 
          pub_path_AGV.publish(Path)
          #esperamos hasta AGV esté en la estación 0:
          while AGV_station0==False:
                rospy.sleep(0.01)
                  
          #esperamos cubo encima AGV y actualizamos batería y posición
          Battery_level=Battery_level-5
          Position=0
          pub_position.publish(Position)
          pub_battery_lvl.publish(Battery_level)    
           
          #2. vemos que tipo de pieza es
          if task==1:         
             #esperamos acabe proceso
             while Cube_ready_st0==False:
                  rospy.sleep(0.01)
                  
             #esperamos por si hay algún AGV en st1:
             while AGV_station1==True:
                   rospy.sleep(0.01)
                   
             Path="/Path0_1"
             pub_path_AGV.publish(Path)
             #esperamos hasta AGV esté en la estación 1:
             while AGV_station1==False:
                  rospy.sleep(0.01)
                 
               
             #actualizamos bateria y posición:
             Battery_level=Battery_level-5
             Position=1
             pub_position.publish(Position)
             pub_battery_lvl.publish(Battery_level)
          
             #esperamos cubo encima AGV(esto incluye ya el tiempo de procesamiento)
             while Cube_ready_st1==False:
                  rospy.sleep(0.01)
       
       
             #esperamos por si hay algún AGV en st 3:
             while AGV_station3==True:
                  rospy.sleep(0.01)
                  
       
             Path="/Path1_3"
             pub_path_AGV.publish(Path)  
             #esperamos hasta AGV esté en la estación 3:
             while AGV_station3==False:
                  rospy.sleep(0.01)
                  
          
             #actualizamos bateria y posición:
             Battery_level=Battery_level-5
             Position=3
             pub_position.publish(Position)
             pub_battery_lvl.publish(Battery_level)
          
             #esperamos cubo encima AGV(esto incluye ya el tiempo de procesamiento)
             while Cube_ready_st3==False:
                  rospy.sleep(0.01)
                  
            
             Path="/Path3_5"
           
          elif task==2:     
             while Cube_ready_st0==False:
                  rospy.sleep(0.01)
          
             #esperamos por si hay algún AGV en st2:
             while AGV_station2==True:
                   rospy.sleep(0.01)
                   
             Path="/Path0_2"
             pub_path_AGV.publish(Path) 
             #esperamos hasta AGV esté en la estación 2:
             while AGV_station2==False:
                  rospy.sleep(0.01)
                  
          
             #actualizamos bateria y posición:
             Battery_level=Battery_level-5
             Position=2
             pub_position.publish(Position)
             pub_battery_lvl.publish(Battery_level)
          
             #esperamos cubo encima AGV(esto incluye ya el tiempo de procesamiento)
             while Cube_ready_st2==False:
                  rospy.sleep(0.01)
                  
             Path="/Path2_4"
             #esperamos por si hay algún AGV en st4:
             while AGV_station4==True:
                   rospy.sleep(0.01)
                   
             #print(Path)
             pub_path_AGV.publish(Path)  
             #esperamos hasta AGV1 esté en la estación 4:
             while AGV_station4==False:
                  rospy.sleep(0.01)
                  
          
             #actualizamos bateria y posición:
             Battery_level=Battery_level-5
             Position=4
             pub_position.publish(Position)
             pub_battery_lvl.publish(Battery_level)
          
             #esperamos cubo encima AGV(esto incluye ya el tiempo de procesamiento)
             while Cube_ready_st4==False:
                  rospy.sleep(0.01)
                  
            
             Path="/Path4_5"
          
          
          #esperamos por si hay algún AGV en st 5:
          while AGV_station5==True:
                rospy.sleep(0.01)
                
       
          pub_path_AGV.publish(Path) 
          
          #esperamos que llegue el AGV
          while AGV_station5==False:
                  rospy.sleep(0.01)
                   
          
          #esperamos AGV listo
          while AGV_ready_st5==False:
                  rospy.sleep(0.01)
                    
          #actualizamos bateria y posición:
          Battery_level=Battery_level-4
          Position=5
          
       #Mandamos al AGV a su sitio si no tiene tarea o se queda donde está si no es el mandado
       else:
       
           if Position==8:
              rospy.sleep(0.001)
           else:
              Path="/Path5_8"
              pub_free.publish(False)
              pub_path_AGV.publish(Path)     
              Position=8
              while AGV_station8==False:
                  rospy.sleep(0.01)
              
     
       
          

     

